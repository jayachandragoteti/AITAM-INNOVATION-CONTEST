<?PHP 
     $connect=mysqli_connect("localhost","root","","aitam_innovation_contest");
     #$connect=mysqli_connect("localhost","id13187334_aitam","jjWoK@2MtCiIRj)o","id13187334_aim");
   
?>