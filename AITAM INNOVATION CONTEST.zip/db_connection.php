<?PHP 
     $connect=mysqli_connect("localhost","root","","aitam_innovation_contest");
     //$connect=mysqli_connect("localhost","id13587141_aitam","<GTxAfhkFhYtc4[[","id13587141_aitaminnovationcontest");
   
   
?>